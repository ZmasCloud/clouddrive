<?php
session_start();
require_once 'config.php';
require_once 'functions.php';

// 获取文件路径和分享代码
$filePath = isset($_GET['file']) ? $_GET['file'] : '';
$shareCode = isset($_GET['code']) ? $_GET['code'] : '';
$filePath = sanitizePath($filePath);
$fullPath = ROOT_DIR . '/' . $filePath;

// 验证分享代码
$isValidShare = false;
if (!empty($shareCode)) {
    try {
        $stmt = $db->prepare("SELECT * FROM shares WHERE share_code = :share_code AND file_path = :file_path");
        $stmt->bindParam(':share_code', $shareCode);
        $stmt->bindParam(':file_path', $filePath);
        $stmt->execute();
        
        $share = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($share && (!$share['expires_at'] || strtotime($share['expires_at']) > time())) {
            $isValidShare = true;
        }
    } catch (PDOException $e) {
        header('HTTP/1.0 500 Internal Server Error');
        exit;
    }
}

// 检查是否有权限访问文件
if (!$isValidShare && !isset($_SESSION['user_id'])) {
    header('HTTP/1.0 403 Forbidden');
    exit;
}

// 检查文件是否存在
if (!file_exists($fullPath) || is_dir($fullPath)) {
    header('HTTP/1.0 404 Not Found');
    exit;
}

// 获取文件MIME类型
$mimeType = getMimeType($fullPath);

// 设置响应头
header('Content-Type: ' . $mimeType);
header('Content-Length: ' . filesize($fullPath));
header('Cache-Control: max-age=86400');

// 输出文件内容
readfile($fullPath);
exit;

