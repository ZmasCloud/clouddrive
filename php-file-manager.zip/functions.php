<?php
/**
 * 格式化文件大小
 */
function formatFileSize($bytes) {
    if ($bytes >= 1073741824) {
        return number_format($bytes / 1073741824, 2) . ' GB';
    } elseif ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 2) . ' MB';
    } elseif ($bytes >= 1024) {
        return number_format($bytes / 1024, 2) . ' KB';
    } else {
        return $bytes . ' B';
    }
}

/**
 * 清理路径，防止目录遍历攻击
 */
function sanitizePath($path) {
    // 移除 ".." 和多余的斜杠
    $path = str_replace(['..', '//'], ['', '/'], $path);
    // 移除开头和结尾的斜杠
    return trim($path, '/');
}

/**
 * 递归删除目录
 */
function deleteDirectory($dir) {
    if (!file_exists($dir)) {
        return true;
    }
    
    if (!is_dir($dir)) {
        return unlink($dir);
    }
    
    foreach (scandir($dir) as $item) {
        if ($item == '.' || $item == '..') {
            continue;
        }
        
        if (!deleteDirectory($dir . DIRECTORY_SEPARATOR . $item)) {
            return false;
        }
    }
    
    return rmdir($dir);
}

/**
 * 生成随机字符串
 */
function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}

/**
 * 获取文件MIME类型
 */
function getMimeType($file) {
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file);
    finfo_close($finfo);
    return $mime;
}

/**
 * 检查文件是否为图片
 */
function isImage($file) {
    $mime = getMimeType($file);
    return strpos($mime, 'image/') === 0;
}

/**
 * 检查文件是否为视频
 */
function isVideo($file) {
    $mime = getMimeType($file);
    return strpos($mime, 'video/') === 0;
}

/**
 * 检查文件是否为音频
 */
function isAudio($file) {
    $mime = getMimeType($file);
    return strpos($mime, 'audio/') === 0;
}

/**
 * 获取文件图标
 */
function getFileIcon($file) {
    $extension = pathinfo($file, PATHINFO_EXTENSION);
    
    $iconMap = [
        // 文档
        'pdf' => 'bi-file-earmark-pdf',
        'doc' => 'bi-file-earmark-word',
        'docx' => 'bi-file-earmark-word',
        'xls' => 'bi-file-earmark-excel',
        'xlsx' => 'bi-file-earmark-excel',
        'ppt' => 'bi-file-earmark-ppt',
        'pptx' => 'bi-file-earmark-ppt',
        'txt' => 'bi-file-earmark-text',
        
        // 图片
        'jpg' => 'bi-file-earmark-image',
        'jpeg' => 'bi-file-earmark-image',
        'png' => 'bi-file-earmark-image',
        'gif' => 'bi-file-earmark-image',
        'svg' => 'bi-file-earmark-image',
        
        // 音频
        'mp3' => 'bi-file-earmark-music',
        'wav' => 'bi-file-earmark-music',
        'ogg' => 'bi-file-earmark-music',
        
        // 视频
        'mp4' => 'bi-file-earmark-play',
        'avi' => 'bi-file-earmark-play',
        'mov' => 'bi-file-earmark-play',
        'wmv' => 'bi-file-earmark-play',
        
        // 压缩文件
        'zip' => 'bi-file-earmark-zip',
        'rar' => 'bi-file-earmark-zip',
        '7z' => 'bi-file-earmark-zip',
        'tar' => 'bi-file-earmark-zip',
        'gz' => 'bi-file-earmark-zip',
        
        // 代码
        'html' => 'bi-file-earmark-code',
        'css' => 'bi-file-earmark-code',
        'js' => 'bi-file-earmark-code',
        'php' => 'bi-file-earmark-code',
        'py' => 'bi-file-earmark-code',
        'java' => 'bi-file-earmark-code',
        'c' => 'bi-file-earmark-code',
        'cpp' => 'bi-file-earmark-code',
    ];
    
    return isset($iconMap[strtolower($extension)]) ? $iconMap[strtolower($extension)] : 'bi-file-earmark';
}

