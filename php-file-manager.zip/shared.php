<?php
session_start();
require_once 'config.php';
require_once 'functions.php';

// 获取分享代码
$shareCode = isset($_GET['code']) ? $_GET['code'] : '';

if (empty($shareCode)) {
    header('Location: index.php');
    exit;
}

// 获取分享信息
try {
    $stmt = $db->prepare("SELECT s.*, u.username FROM shares s JOIN users u ON s.user_id = u.id WHERE s.share_code = :share_code");
    $stmt->bindParam(':share_code', $shareCode);
    $stmt->execute();
    
    $share = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$share) {
        $error = '分享链接不存在或已过期';
    } else {
        // 检查是否过期
        if ($share['expires_at'] && strtotime($share['expires_at']) < time()) {
            $error = '分享链接已过期';
        } else {
            $filePath = $share['file_path'];
            $fullPath = ROOT_DIR . '/' . $filePath;
            
            if (!file_exists($fullPath)) {
                $error = '文件不存在或已被删除';
            } else {
                $fileName = basename($fullPath);
                $fileSize = formatFileSize(filesize($fullPath));
                $fileType = is_dir($fullPath) ? '文件夹' : pathinfo($fullPath, PATHINFO_EXTENSION);
                $fileIcon = is_dir($fullPath) ? 'bi-folder' : getFileIcon($fullPath);
                $isImage = !is_dir($fullPath) && isImage($fullPath);
                $isVideo = !is_dir($fullPath) && isVideo($fullPath);
                $isAudio = !is_dir($fullPath) && isAudio($fullPath);
            }
        }
    }
} catch (PDOException $e) {
    $error = '获取分享信息失败: ' . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>查看分享 - PHP 文件管理系统</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="bi bi-cloud me-2"></i>PHP 文件管理系统
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">首页</a>
                    </li>
                </ul>
                <div class="d-flex">
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <a href="logout.php" class="btn btn-outline-light">退出登录</a>
                    <?php else: ?>
                        <a href="login.php" class="btn btn-outline-light me-2">登录</a>
                        <a href="register.php" class="btn btn-light">注册</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <div class="container my-4">
        <?php if (isset($error)): ?>
            <div class="alert alert-danger">
                <h4 class="alert-heading">错误</h4>
                <p><?php echo htmlspecialchars($error); ?></p>
                <hr>
                <p class="mb-0">
                    <a href="index.php" class="alert-link">返回首页</a>
                </p>
            </div>
        <?php else: ?>
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">
                        <i class="bi bi-share me-2"></i>分享文件
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4 mb-4">
                            <div class="text-center mb-4">
                                <?php if ($isImage): ?>
                                    <img src="preview.php?file=<?php echo urlencode($filePath); ?>&code=<?php echo urlencode($shareCode); ?>" 
                                         class="img-fluid rounded" alt="<?php echo htmlspecialchars($fileName); ?>">
                                <?php else: ?>
                                    <i class="<?php echo $fileIcon; ?> display-1 text-primary"></i>
                                <?php endif; ?>
                            </div>
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>文件名</span>
                                    <span class="text-truncate ms-2" style="max-width: 200px;"><?php echo htmlspecialchars($fileName); ?></span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>大小</span>
                                    <span><?php echo $fileSize; ?></span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>类型</span>
                                    <span><?php echo htmlspecialchars($fileType); ?></span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>分享者</span>
                                    <span><?php echo htmlspecialchars($share['username']); ?></span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>分享时间</span>
                                    <span><?php echo date('Y-m-d', strtotime($share['created_at'])); ?></span>
                                </li>
                                <?php if ($share['expires_at']): ?>
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>过期时间</span>
                                    <span><?php echo date('Y-m-d', strtotime($share['expires_at'])); ?></span>
                                </li>
                                <?php endif; ?>
                            </ul>
                        </div>
                        
                        <div class="col-md-8">
                            <?php if ($isVideo): ?>
                                <div class="ratio ratio-16x9 mb-3">
                                    <video controls>
                                        <source src="preview.php?file=<?php echo urlencode($filePath); ?>&code=<?php echo urlencode($shareCode); ?>" type="<?php echo getMimeType($fullPath); ?>">
                                        您的浏览器不支持视频播放。
                                    </video>
                                </div>
                            <?php elseif ($isAudio): ?>
                                <div class="card mb-3">
                                    <div class="card-body">
                                        <audio controls class="w-100">
                                            <source src="preview.php?file=<?php echo urlencode($filePath); ?>&code=<?php echo urlencode($shareCode); ?>" type="<?php echo getMimeType($fullPath); ?>">
                                            您的浏览器不支持音频播放。
                                        </audio>
                                    </div>
                                </div>
                            <?php endif; ?>
                            
                            <div class="d-grid gap-2">
                                <a href="download.php?file=<?php echo urlencode($filePath); ?>&code=<?php echo urlencode($shareCode); ?>" class="btn btn-primary btn-lg">
                                    <i class="bi bi-download me-2"></i>下载文件
                                </a>
                                <?php if (isset($_SESSION['user_id'])): ?>
                                    <a href="save.php?file=<?php echo urlencode($filePath); ?>&code=<?php echo urlencode($shareCode); ?>" class="btn btn-outline-primary">
                                        <i class="bi bi-save me-2"></i>保存到我的文件
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <footer class="bg-light py-4 mt-5">
        <div class="container text-center">
            <p class="mb-0">PHP 文件管理系统 &copy; <?php echo date('Y'); ?></p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

