<?php
session_start();
require_once 'config.php';
require_once 'functions.php';

// 检查是否已登录
$isLoggedIn = isset($_SESSION['user_id']);

// 获取当前路径
$currentPath = isset($_GET['path']) ? $_GET['path'] : '';
$currentPath = sanitizePath($currentPath);
$fullPath = ROOT_DIR . '/' . $currentPath;

// 创建目录（如果不存在）
if (!file_exists($fullPath)) {
    mkdir($fullPath, 0755, true);
}

// 处理文件上传
if (isset($_POST['upload']) && $isLoggedIn) {
    if (isset($_FILES['file']) && $_FILES['file']['error'] == 0) {
        $targetFile = $fullPath . '/' . basename($_FILES['file']['name']);
        if (move_uploaded_file($_FILES['file']['tmp_name'], $targetFile)) {
            $message = "文件上传成功！";
        } else {
            $error = "文件上传失败，请重试。";
        }
    }
}

// 处理新建文件夹
if (isset($_POST['create_folder']) && $isLoggedIn) {
    $folderName = sanitizePath($_POST['folder_name']);
    if (!empty($folderName)) {
        $newFolder = $fullPath . '/' . $folderName;
        if (!file_exists($newFolder)) {
            if (mkdir($newFolder, 0755)) {
                $message = "文件夹创建成功！";
            } else {
                $error = "文件夹创建失败，请重试。";
            }
        } else {
            $error = "文件夹已存在！";
        }
    }
}

// 处理删除文件/文件夹
if (isset($_GET['delete']) && $isLoggedIn) {
    $deleteItem = sanitizePath($_GET['delete']);
    $deleteItemPath = $fullPath . '/' . $deleteItem;
    
    if (file_exists($deleteItemPath)) {
        if (is_dir($deleteItemPath)) {
            if (deleteDirectory($deleteItemPath)) {
                $message = "文件夹删除成功！";
            } else {
                $error = "文件夹删除失败，请重试。";
            }
        } else {
            if (unlink($deleteItemPath)) {
                $message = "文件删除成功！";
            } else {
                $error = "文件删除失败，请重试。";
            }
        }
    }
}

// 获取当前目录的文件和文件夹
$items = [];
if ($handle = opendir($fullPath)) {
    while (false !== ($entry = readdir($handle))) {
        if ($entry != "." && $entry != "..") {
            $itemPath = $fullPath . '/' . $entry;
            $items[] = [
                'name' => $entry,
                'path' => $currentPath ? $currentPath . '/' . $entry : $entry,
                'is_dir' => is_dir($itemPath),
                'size' => is_dir($itemPath) ? '-' : formatFileSize(filesize($itemPath)),
                'modified' => date("Y-m-d H:i:s", filemtime($itemPath))
            ];
        }
    }
    closedir($handle);
}

// 按类型排序：文件夹在前，文件在后
usort($items, function($a, $b) {
    if ($a['is_dir'] && !$b['is_dir']) {
        return -1;
    }
    if (!$a['is_dir'] && $b['is_dir']) {
        return 1;
    }
    return strcasecmp($a['name'], $b['name']);
});

// 生成面包屑导航
$breadcrumbs = [];
if (!empty($currentPath)) {
    $parts = explode('/', $currentPath);
    $breadcrumbPath = '';
    foreach ($parts as $part) {
        $breadcrumbPath .= ($breadcrumbPath ? '/' : '') . $part;
        $breadcrumbs[] = [
            'name' => $part,
            'path' => $breadcrumbPath
        ];
    }
}

// 页面标题
$pageTitle = empty($currentPath) ? '根目录' : basename($currentPath);
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP 文件管理系统 - <?php echo htmlspecialchars($pageTitle); ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="bi bi-cloud me-2"></i>PHP 文件管理系统
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">首页</a>
                    </li>
                    <?php if ($isLoggedIn): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="settings.php">设置</a>
                    </li>
                    <?php endif; ?>
                </ul>
                <div class="d-flex">
                    <?php if ($isLoggedIn): ?>
                        <a href="logout.php" class="btn btn-outline-light">退出登录</a>
                    <?php else: ?>
                        <a href="login.php" class="btn btn-outline-light me-2">登录</a>
                        <a href="register.php" class="btn btn-light">注册</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <div class="container my-4">
        <?php if (isset($message)): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo htmlspecialchars($message); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <?php echo htmlspecialchars($error); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <div>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item"><a href="index.php">根目录</a></li>
                            <?php foreach ($breadcrumbs as $breadcrumb): ?>
                                <li class="breadcrumb-item">
                                    <a href="index.php?path=<?php echo urlencode($breadcrumb['path']); ?>">
                                        <?php echo htmlspecialchars($breadcrumb['name']); ?>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ol>
                    </nav>
                </div>
                <?php if ($isLoggedIn): ?>
                <div>
                    <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#uploadModal">
                        <i class="bi bi-upload me-1"></i>上传文件
                    </button>
                    <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#folderModal">
                        <i class="bi bi-folder-plus me-1"></i>新建文件夹
                    </button>
                </div>
                <?php endif; ?>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th style="width: 50%">名称</th>
                                <th>大小</th>
                                <th>修改时间</th>
                                <?php if ($isLoggedIn): ?>
                                <th>操作</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($currentPath)): ?>
                            <tr>
                                <td>
                                    <a href="index.php?path=<?php echo urlencode(dirname($currentPath)); ?>" class="text-decoration-none">
                                        <i class="bi bi-arrow-up-circle text-primary me-2"></i>..
                                    </a>
                                </td>
                                <td>-</td>
                                <td>-</td>
                                <?php if ($isLoggedIn): ?>
                                <td>-</td>
                                <?php endif; ?>
                            </tr>
                            <?php endif; ?>
                            
                            <?php foreach ($items as $item): ?>
                            <tr>
                                <td>
                                    <?php if ($item['is_dir']): ?>
                                    <a href="index.php?path=<?php echo urlencode($item['path']); ?>" class="text-decoration-none">
                                        <i class="bi bi-folder text-warning me-2"></i><?php echo htmlspecialchars($item['name']); ?>
                                    </a>
                                    <?php else: ?>
                                    <a href="download.php?file=<?php echo urlencode($item['path']); ?>" class="text-decoration-none">
                                        <i class="bi bi-file-earmark text-secondary me-2"></i><?php echo htmlspecialchars($item['name']); ?>
                                    </a>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo $item['size']; ?></td>
                                <td><?php echo $item['modified']; ?></td>
                                <?php if ($isLoggedIn): ?>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <a href="share.php?file=<?php echo urlencode($item['path']); ?>" class="btn btn-outline-primary">
                                            <i class="bi bi-share"></i>
                                        </a>
                                        <a href="index.php?path=<?php echo urlencode($currentPath); ?>&delete=<?php echo urlencode($item['name']); ?>" 
                                           class="btn btn-outline-danger" 
                                           onclick="return confirm('确定要删除 <?php echo htmlspecialchars($item['name']); ?> 吗？')">
                                            <i class="bi bi-trash"></i>
                                        </a>
                                    </div>
                                </td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; ?>
                            
                            <?php if (empty($items)): ?>
                            <tr>
                                <td colspan="<?php echo $isLoggedIn ? '4' : '3'; ?>" class="text-center py-4">
                                    <i class="bi bi-inbox display-4 d-block text-muted"></i>
                                    <p class="text-muted">此文件夹为空</p>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <?php if ($isLoggedIn): ?>
    <!-- 上传文件模态框 -->
    <div class="modal fade" id="uploadModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">上传文件</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form action="index.php?path=<?php echo urlencode($currentPath); ?>" method="post" enctype="multipart/form-data">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="file" class="form-label">选择文件</label>
                            <input type="file" class="form-control" id="file" name="file" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                        <button type="submit" name="upload" class="btn btn-primary">上传</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- 新建文件夹模态框 -->
    <div class="modal fade" id="folderModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">新建文件夹</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form action="index.php?path=<?php echo urlencode($currentPath); ?>" method="post">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="folder_name" class="form-label">文件夹名称</label>
                            <input type="text" class="form-control" id="folder_name" name="folder_name" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                        <button type="submit" name="create_folder" class="btn btn-primary">创建</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <footer class="bg-light py-4 mt-5">
        <div class="container text-center">
            <p class="mb-0">PHP 文件管理系统 &copy; <?php echo date('Y'); ?></p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

