<?php
session_start();
require_once 'config.php';
require_once 'functions.php';

// 检查是否已登录
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// 获取文件路径和分享代码
$filePath = isset($_GET['file']) ? $_GET['file'] : '';
$shareCode = isset($_GET['code']) ? $_GET['code'] : '';
$filePath = sanitizePath($filePath);

if (empty($filePath) || empty($shareCode)) {
    header('Location: index.php');
    exit;
}

// 验证分享代码
try {
    $stmt = $db->prepare("SELECT * FROM shares WHERE share_code = :share_code AND file_path = :file_path");
    $stmt->bindParam(':share_code', $shareCode);
    $stmt->bindParam(':file_path', $filePath);
    $stmt->execute();
    
    $share = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$share || ($share['expires_at'] && strtotime($share['expires_at']) < time())) {
        $_SESSION['error'] = '分享链接不存在或已过期';
        header('Location: index.php');
        exit;
    }
    
    // 检查文件是否存在
    $sourceFile = ROOT_DIR . '/' . $filePath;
    if (!file_exists($sourceFile)) {
        $_SESSION['error'] = '文件不存在或已被删除';
        header('Location: index.php');
        exit;
    }
    
    // 创建目标目录
    $fileName = basename($filePath);
    $targetDir = ROOT_DIR . '/saved_' . $_SESSION['user_id'];
    if (!file_exists($targetDir)) {
        mkdir($targetDir, 0755, true);
    }
    
    $targetFile = $targetDir . '/' . $fileName;
    
    // 如果目标文件已存在，添加数字后缀
    if (file_exists($targetFile)) {
        $fileInfo = pathinfo($fileName);
        $extension = isset($fileInfo['extension']) ? '.' . $fileInfo['extension'] : '';
        $name = $fileInfo['filename'];
        
        $counter = 1;
        while (file_exists($targetDir . '/' . $name . '_' . $counter . $extension)) {
            $counter++;
        }
        
        $targetFile = $targetDir . '/' . $name . '_' . $counter . $extension;
        $fileName = $name . '_' . $counter . $extension;
    }
    
    // 复制文件
    if (copy($sourceFile, $targetFile)) {
        $_SESSION['success'] = '文件已成功保存到您的文件夹';
        header('Location: index.php?path=saved_' . $_SESSION['user_id']);
        exit;
    } else {
        $_SESSION['error'] = '保存文件失败，请重试';
        header('Location: index.php');
        exit;
    }
} catch (PDOException $e) {
    $_SESSION['error'] = '操作失败: ' . $e->getMessage();
    header('Location: index.php');
    exit;
}

