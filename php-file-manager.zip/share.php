<?php
session_start();
require_once 'config.php';
require_once 'functions.php';

// 检查是否已登录
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$error = '';
$success = '';
$shareUrl = '';

// 获取文件路径
$filePath = isset($_GET['file']) ? $_GET['file'] : '';
$filePath = sanitizePath($filePath);
$fullPath = ROOT_DIR . '/' . $filePath;

// 检查文件是否存在
if (!file_exists($fullPath)) {
    header('Location: index.php');
    exit;
}

// 处理分享表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $expiresAt = null;
    
    if (isset($_POST['expires']) && $_POST['expires'] > 0) {
        $expiresAt = date('Y-m-d H:i:s', strtotime('+' . $_POST['expires'] . ' days'));
    }
    
    try {
        // 检查是否已经分享过该文件
        $stmt = $db->prepare("SELECT id, share_code FROM shares WHERE user_id = :user_id AND file_path = :file_path");
        $stmt->bindParam(':user_id', $_SESSION['user_id']);
        $stmt->bindParam(':file_path', $filePath);
        $stmt->execute();
        
        if ($share = $stmt->fetch(PDO::FETCH_ASSOC)) {
            // 更新现有分享
            $stmt = $db->prepare("UPDATE shares SET expires_at = :expires_at WHERE id = :id");
            $stmt->bindParam(':expires_at', $expiresAt);
            $stmt->bindParam(':id', $share['id']);
            $stmt->execute();
            
            $shareCode = $share['share_code'];
        } else {
            // 创建新分享
            $shareCode = generateRandomString(10);
            
            $stmt = $db->prepare("INSERT INTO shares (user_id, file_path, share_code, expires_at) VALUES (:user_id, :file_path, :share_code, :expires_at)");
            $stmt->bindParam(':user_id', $_SESSION['user_id']);
            $stmt->bindParam(':file_path', $filePath);
            $stmt->bindParam(':share_code', $shareCode);
            $stmt->bindParam(':expires_at', $expiresAt);
            $stmt->execute();
        }
        
        $shareUrl = SITE_URL . '/shared.php?code=' . $shareCode;
        $success = '文件分享成功！';
    } catch (PDOException $e) {
        $error = '分享失败: ' . $e->getMessage();
    }
}

// 获取文件信息
$fileName = basename($fullPath);
$fileSize = formatFileSize(filesize($fullPath));
$fileType = is_dir($fullPath) ? '文件夹' : pathinfo($fullPath, PATHINFO_EXTENSION);
$fileIcon = is_dir($fullPath) ? 'bi-folder' : getFileIcon($fullPath);

// 检查文件是否已经分享
$existingShare = null;
try {
    $stmt = $db->prepare("SELECT share_code, created_at, expires_at FROM shares WHERE user_id = :user_id AND file_path = :file_path");
    $stmt->bindParam(':user_id', $_SESSION['user_id']);
    $stmt->bindParam(':file_path', $filePath);
    $stmt->execute();
    
    $existingShare = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($existingShare) {
        $shareUrl = SITE_URL . '/shared.php?code=' . $existingShare['share_code'];
    }
} catch (PDOException $e) {
    $error = '获取分享信息失败: ' . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>分享文件 - PHP 文件管理系统</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="bi bi-cloud me-2"></i>PHP 文件管理系统
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">首页</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="settings.php">设置</a>
                    </li>
                </ul>
                <div class="d-flex">
                    <a href="logout.php" class="btn btn-outline-light">退出登录</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container my-4">
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <?php echo htmlspecialchars($error); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($success)): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo htmlspecialchars($success); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">文件信息</h5>
                    </div>
                    <div class="card-body">
                        <div class="text-center mb-4">
                            <i class="<?php echo $fileIcon; ?> display-1 text-primary"></i>
                        </div>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item d-flex justify-content-between">
                                <span>文件名</span>
                                <span class="text-truncate ms-2" style="max-width: 200px;"><?php echo htmlspecialchars($fileName); ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>大小</span>
                                <span><?php echo $fileSize; ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>类型</span>
                                <span><?php echo htmlspecialchars($fileType); ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>路径</span>
                                <span class="text-truncate ms-2" style="max-width: 200px;"><?php echo htmlspecialchars($filePath); ?></span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">分享文件</h5>
                    </div>
                    <div class="card-body">
                        <?php if ($existingShare): ?>
                            <div class="alert alert-info">
                                <p>此文件已分享于 <?php echo date('Y-m-d H:i:s', strtotime($existingShare['created_at'])); ?></p>
                                <?php if ($existingShare['expires_at']): ?>
                                    <p>分享链接将于 <?php echo date('Y-m-d H:i:s', strtotime($existingShare['expires_at'])); ?> 过期</p>
                                <?php else: ?>
                                    <p>此分享链接永不过期</p>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                        
                        <form method="post" action="share.php?file=<?php echo urlencode($filePath); ?>">
                            <div class="mb-3">
                                <label for="expires" class="form-label">过期时间</label>
                                <select class="form-select" id="expires" name="expires">
                                    <option value="0">永不过期</option>
                                    <option value="1">1天</option>
                                    <option value="7">7天</option>
                                    <option value="30">30天</option>
                                    <option value="90">90天</option>
                                </select>
                            </div>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo $existingShare ? '更新分享' : '分享文件'; ?>
                                </button>
                            </div>
                        </form>
                        
                        <?php if (!empty($shareUrl)): ?>
                            <div class="mt-4">
                                <label class="form-label">分享链接</label>
                                <div class="input-group">
                                    <input type="text" class="form-control" id="shareUrl" value="<?php echo htmlspecialchars($shareUrl); ?>" readonly>
                                    <button class="btn btn-outline-secondary" type="button" onclick="copyShareUrl()">
                                        <i class="bi bi-clipboard"></i>
                                    </button>
                                </div>
                                <div class="form-text" id="copyMessage"></div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="mt-3">
                    <a href="index.php?path=<?php echo urlencode(dirname($filePath)); ?>" class="btn btn-outline-secondary">
                        <i class="bi bi-arrow-left me-1"></i>返回
                    </a>
                </div>
            </div>
        </div>
    </div>

    <footer class="bg-light py-4 mt-5">
        <div class="container text-center">
            <p class="mb-0">PHP 文件管理系统 &copy; <?php echo date('Y'); ?></p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function copyShareUrl() {
            const shareUrl = document.getElementById('shareUrl');
            const copyMessage = document.getElementById('copyMessage');
            
            shareUrl.select();
            shareUrl.setSelectionRange(0, 99999);
            
            navigator.clipboard.writeText(shareUrl.value)
                .then(() => {
                    copyMessage.textContent = '链接已复制到剪贴板！';
                    copyMessage.classList.add('text-success');
                    
                    setTimeout(() => {
                        copyMessage.textContent = '';
                    }, 3000);
                })
                .catch(err => {
                    copyMessage.textContent = '复制失败，请手动复制链接。';
                    copyMessage.classList.add('text-danger');
                });
        }
    </script>
</body>
</html>

