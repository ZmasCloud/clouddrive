<?php
session_start();
require_once 'config.php';

// 检查是否已登录
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$error = '';
$success = '';

// 处理修改密码表单提交
if (isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
        $error = '请填写所有密码字段';
    } elseif ($new_password !== $confirm_password) {
        $error = '新密码与确认密码不一致';
    } elseif (strlen($new_password) < 6) {
        $error = '新密码长度至少为6个字符';
    } else {
        try {
            // 验证当前密码
            $stmt = $db->prepare("SELECT password FROM users WHERE id = :user_id");
            $stmt->bindParam(':user_id', $_SESSION['user_id']);
            $stmt->execute();
            
            if ($user = $stmt->fetch(PDO::FETCH_ASSOC)) {
                if (password_verify($current_password, $user['password'])) {
                    // 更新密码
                    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                    
                    $stmt = $db->prepare("UPDATE users SET password = :password WHERE id = :user_id");
                    $stmt->bindParam(':password', $hashed_password);
                    $stmt->bindParam(':user_id', $_SESSION['user_id']);
                    $stmt->execute();
                    
                    $success = '密码修改成功！';
                } else {
                    $error = '当前密码不正确';
                }
            } else {
                $error = '用户不存在';
            }
        } catch (PDOException $e) {
            $error = '修改密码失败: ' . $e->getMessage();
        }
    }
}

// 获取用户信息
try {
    $stmt = $db->prepare("SELECT username, email, created_at FROM users WHERE id = :user_id");
    $stmt->bindParam(':user_id', $_SESSION['user_id']);
    $stmt->execute();
    
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = '获取用户信息失败: ' . $e->getMessage();
}

// 获取用户分享统计
try {
    $stmt = $db->prepare("SELECT COUNT(*) as share_count FROM shares WHERE user_id = :user_id");
    $stmt->bindParam(':user_id', $_SESSION['user_id']);
    $stmt->execute();
    
    $shareStats = $stmt->fetch(PDO::FETCH_ASSOC);
    $shareCount = $shareStats['share_count'];
} catch (PDOException $e) {
    $shareCount = 0;
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>设置 - PHP 文件管理系统</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="bi bi-cloud me-2"></i>PHP 文件管理系统
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">首页</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="settings.php">设置</a>
                    </li>
                </ul>
                <div class="d-flex">
                    <a href="logout.php" class="btn btn-outline-light">退出登录</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container my-4">
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <?php echo htmlspecialchars($error); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($success)): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo htmlspecialchars($success); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">个人资料</h5>
                    </div>
                    <div class="card-body">
                        <div class="text-center mb-4">
                            <div class="avatar-circle mx-auto mb-3">
                                <span class="avatar-text"><?php echo strtoupper(substr($user['username'], 0, 1)); ?></span>
                            </div>
                            <h5 class="mb-0"><?php echo htmlspecialchars($user['username']); ?></h5>
                            <p class="text-muted"><?php echo htmlspecialchars($user['email']); ?></p>
                        </div>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item d-flex justify-content-between">
                                <span>注册时间</span>
                                <span><?php echo date('Y-m-d', strtotime($user['created_at'])); ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between">
                                <span>分享数量</span>
                                <span><?php echo $shareCount; ?></span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">修改密码</h5>
                    </div>
                    <div class="card-body">
                        <form method="post" action="settings.php">
                            <div class="mb-3">
                                <label for="current_password" class="form-label">当前密码</label>
                                <input type="password" class="form-control" id="current_password" name="current_password" required>
                            </div>
                            <div class="mb-3">
                                <label for="new_password" class="form-label">新密码</label>
                                <input type="password" class="form-control" id="new_password" name="new_password" required>
                                <div class="form-text">密码长度至少为6个字符</div>
                            </div>
                            <div class="mb-3">
                                <label for="confirm_password" class="form-label">确认新密码</label>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                            </div>
                            <div class="d-grid">
                                <button type="submit" name="change_password" class="btn btn-primary">修改密码</button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <div class="card mt-4">
                    <div class="card-header">
                        <h5 class="card-title mb-0">我的分享</h5>
                    </div>
                    <div class="card-body">
                        <?php
                        try {
                            $stmt = $db->prepare("
                                SELECT s.*, u.username 
                                FROM shares s 
                                JOIN users u ON s.user_id = u.id 
                                WHERE s.user_id = :user_id
                                ORDER BY s.created_at DESC
                            ");
                            $stmt->bindParam(':user_id', $_SESSION['user_id']);
                            $stmt->execute();
                            
                            $shares = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        } catch (PDOException $e) {
                            $shares = [];
                        }
                        ?>
                        
                        <?php if (empty($shares)): ?>
                            <div class="text-center py-4">
                                <i class="bi bi-share display-4 d-block text-muted"></i>
                                <p class="text-muted">您还没有分享任何文件</p>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>文件路径</th>
                                            <th>分享时间</th>
                                            <th>过期时间</th>
                                            <th>操作</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($shares as $share): ?>
                                            <tr>
                                                <td class="text-truncate" style="max-width: 200px;">
                                                    <?php echo htmlspecialchars($share['file_path']); ?>
                                                </td>
                                                <td><?php echo date('Y-m-d', strtotime($share['created_at'])); ?></td>
                                                <td>
                                                    <?php if ($share['expires_at']): ?>
                                                        <?php echo date('Y-m-d', strtotime($share['expires_at'])); ?>
                                                    <?php else: ?>
                                                        永不过期
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <div class="btn-group btn-group-sm">
                                                        <a href="shared.php?code=<?php echo urlencode($share['share_code']); ?>" class="btn btn-outline-primary">
                                                            <i class="bi bi-eye"></i>
                                                        </a>
                                                        <a href="share.php?file=<?php echo urlencode($share['file_path']); ?>" class="btn btn-outline-secondary">
                                                            <i class="bi bi-pencil"></i>
                                                        </a>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="bg-light py-4 mt-5">
        <div class="container text-center">
            <p class="mb-0">PHP 文件管理系统 &copy; <?php echo date('Y'); ?></p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

