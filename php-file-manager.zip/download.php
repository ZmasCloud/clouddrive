<?php
session_start();
require_once 'config.php';
require_once 'functions.php';

// 获取文件路径
$filePath = isset($_GET['file']) ? $_GET['file'] : '';
$filePath = sanitizePath($filePath);
$fullPath = ROOT_DIR . '/' . $filePath;

// 检查文件是否存在
if (!file_exists($fullPath) || is_dir($fullPath)) {
    header('HTTP/1.0 404 Not Found');
    echo '文件不存在';
    exit;
}

// 获取文件信息
$fileName = basename($fullPath);
$fileSize = filesize($fullPath);
$mimeType = getMimeType($fullPath);

// 设置响应头
header('Content-Description: File Transfer');
header('Content-Type: ' . $mimeType);
header('Content-Disposition: attachment; filename="' . $fileName . '"');
header('Content-Length: ' . $fileSize);
header('Expires: 0');
header('Cache-Control: must-revalidate');
header('Pragma: public');

// 输出文件内容
readfile($fullPath);
exit;

