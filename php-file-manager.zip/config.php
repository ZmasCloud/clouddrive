<?php
// 数据库配置
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'file_manager');

// 应用配置
define('ROOT_DIR', __DIR__ . '/uploads');
define('SITE_URL', 'http://localhost/file-manager');
define('SITE_NAME', 'PHP 文件管理系统');

// 创建上传目录（如果不存在）
if (!file_exists(ROOT_DIR)) {
    mkdir(ROOT_DIR, 0755, true);
}

// 连接数据库
try {
    $db = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $db->exec("SET NAMES utf8");
} catch (PDOException $e) {
    // 如果数据库连接失败，尝试创建数据库
    try {
        $tempDb = new PDO("mysql:host=" . DB_HOST, DB_USER, DB_PASS);
        $tempDb->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $tempDb->exec("CREATE DATABASE IF NOT EXISTS " . DB_NAME . " CHARACTER SET utf8 COLLATE utf8_general_ci");
        $tempDb->exec("USE " . DB_NAME);
        
        // 创建用户表
        $tempDb->exec("
            CREATE TABLE IF NOT EXISTS users (
                id INT(11) NOT NULL AUTO_INCREMENT,
                username VARCHAR(50) NOT NULL,
                password VARCHAR(255) NOT NULL,
                email VARCHAR(100) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY (username),
                UNIQUE KEY (email)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
        ");
        
        // 创建分享表
        $tempDb->exec("
            CREATE TABLE IF NOT EXISTS shares (
                id INT(11) NOT NULL AUTO_INCREMENT,
                user_id INT(11) NOT NULL,
                file_path VARCHAR(255) NOT NULL,
                share_code VARCHAR(32) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                expires_at TIMESTAMP NULL DEFAULT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY (share_code)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
        ");
        
        $db = $tempDb;
    } catch (PDOException $e2) {
        die("数据库连接失败: " . $e2->getMessage());
    }
}

